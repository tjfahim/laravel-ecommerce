{{-- @extends('base') --}}
<div>
    User Dashboard
</div>

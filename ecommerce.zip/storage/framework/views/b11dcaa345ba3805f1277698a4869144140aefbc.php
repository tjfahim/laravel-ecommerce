
<div>
    User Dashboard
</div>
<?php /**PATH C:\xampp\htdocs\laravel2\ecommerce\resources\views/livewire/user/user-dashboard-component.blade.php ENDPATH**/ ?>